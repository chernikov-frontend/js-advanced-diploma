class Game {
    constructor() {
      this.theme = 'prairie'; // Устанавливаем начальную тему
    }
  
    setTheme(newTheme) {
      this.theme = newTheme;
    }
  
    getTheme() {
      return this.theme;
    }
  } 