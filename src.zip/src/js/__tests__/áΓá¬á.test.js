import GameController from '../GameController';
import Swordsman from '../characters/Swordsman';
import GamePlay from '../GamePlay';

// Тест для проверки силы атаки при повышении уровня выжившего персонажа

describe('Повышение уровня персонажа', () => {
  let gameController;
  let mockGamePlay;

  beforeEach(() => {
    mockGamePlay = new GamePlay();
    mockGamePlay.boardSize = 8; // Устанавливаем значение для boardSize в mock
    gameController = new GameController(mockGamePlay, {});
  });

  test('должен корректно пересчитывать атаку после повышения уровня', () => {
    const initialAttack = 50;
    const healthLevels = [
      { health: 50, expectedMultiplier: 1.3 },  // 50% жизни, повышение на 30%
      { health: 1, expectedMultiplier: 1 },     // 1% жизни, показатели не изменятся
      { health: 100, expectedMultiplier: 1.8 }, // 100% жизни, повышение на 80%
    ];

    healthLevels.forEach(({ health, expectedMultiplier }) => {
      const swordsman = new Swordsman(1);
      swordsman.attack = initialAttack;
      swordsman.health = health;

      // Уровень повышается
      gameController.levelUp(swordsman);

      const expectedAttack = Math.max(initialAttack, initialAttack * (80 + health) / 100);
      expect(swordsman.attack).toBeCloseTo(expectedAttack);
    });
  });
});
